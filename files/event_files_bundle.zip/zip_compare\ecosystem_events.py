"""
Compatibility adapters for the extracted simulation project.

This module keeps the original import surface (`Blizzard`, `GlacierCollapse`,
`Starvation`, `AiBoilingApocalypse`) while also exposing the newer persistent
event managers (`EventTerrestrial`, `EventMarine`, `EventEnd`).
"""

from __future__ import annotations

import sys
from pathlib import Path


CURRENT_DIR = Path(__file__).resolve().parent
PARENT_DIR = CURRENT_DIR.parent
if str(PARENT_DIR) not in sys.path:
    sys.path.insert(0, str(PARENT_DIR))

from event_end import EventEnd  # noqa: E402
from event_marine import EventMarine  # noqa: E402
from event_terrestrial import EventTerrestrial  # noqa: E402


class Event:
    name = "Event"

    def trigger(self, sim):
        return []


class Blizzard(Event):
    """Legacy one-shot wrapper around the newer terrestrial event manager."""

    name = "Blizzard"

    def trigger(self, sim):
        event = EventTerrestrial(
            world_width=sim.world_w,
            world_height=sim.world_h,
            sea_line=sim.sea_line,
        )
        event.BLIZZARD_DURATION = 1
        event.BLIZZARD_DAMAGE_BASE = 14.0
        event.BLIZZARD_COLD_THRESHOLD = 0.7
        return event.blizzard(sim)


class GlacierCollapse(Event):
    """Legacy one-shot wrapper around glacier collapse."""

    name = "GlacierCollapse"

    def trigger(self, sim):
        event = EventTerrestrial(
            world_width=sim.world_w,
            world_height=sim.world_h,
            sea_line=sim.sea_line,
        )
        event.GLACIER_COLLAPSE_RADIUS = 6.0
        event.GLACIER_COLLAPSE_DAMAGE = 18.0
        return event.glacier_collapse(sim) or []


class Starvation(Event):
    """Legacy one-shot wrapper around the marine starvation event."""

    name = "Starvation"

    def trigger(self, sim):
        event = EventMarine(
            world_width=sim.world_w,
            world_height=sim.world_h,
            sea_line=sim.sea_line,
        )
        event.STARVATION_THRESHOLD = 400.0
        event.STARVATION_RECOVERY_THRESHOLD = 500.0
        event.STARVATION_HUNGER_BONUS = 4
        return event.starvation(sim)


class AiBoilingApocalypse(Event):
    """Legacy immediate end-event wrapper for the extracted simulation."""

    name = "AiBoilingApocalypse"

    def trigger(self, sim):
        event = EventEnd(
            warning_duration=0,
            warning_label="AI Warning",
            impact_label="AI Boiling Apocalypse",
            end_reason="AI warming collapsed the ecosystem.",
        )
        return event.trigger(sim)
